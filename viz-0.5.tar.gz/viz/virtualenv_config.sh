# The directory to install the virtualenv in. You can change this if you want
# to install somewhere else.
readonly VIRTUALENV_DIR="$HOME/.virtualenvs/281-p4-viz"
