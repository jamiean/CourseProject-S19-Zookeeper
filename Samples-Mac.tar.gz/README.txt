There are two input files, sample-ab.txt and sample-c.txt.
  sample-ab.txt has 10000 vertices, sample-c.txt has 30.

There are output files for sample-ab.txt run with MST and FASTTSP,
while sample-c.txt was run with all 3 modes.
